package com.example.assignment;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.content.Intent;

public class MainActivity extends Activity {

    private EditText kWh_usage;
    private EditText rebate_percent;
    private TextView cost_result;
    private Button calculate;
    private Button clear;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        kWh_usage = findViewById(R.id.kWh_usage);
        rebate_percent = findViewById(R.id.rebate_percent);
        cost_result = findViewById(R.id.cost_result);
        calculate = findViewById(R.id.calculate);
        clear = findViewById(R.id.clear);
        Button about = findViewById(R.id.about);

        calculate.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                calculateCost();
            }
        });

        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                kWh_usage.setText("");
                rebate_percent.setText("");
                cost_result.setText("");
            }
        });

        about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, About.class);
                startActivity(intent);
            }
         });
    }
    private void calculateCost()
    {
        String usageString = kWh_usage.getText().toString().trim();
        String rebateString = rebate_percent.getText().toString().trim();

        if (usageString.isEmpty() || rebateString.isEmpty())
        {
            cost_result.setText("Please enter both unit used and rebate values.");
        }

        else
        {
            float usage = Float.parseFloat(usageString);
            float rebate = Float.parseFloat(rebateString);

            if (usage < 1 || usage > 900)
            {
                cost_result.setText("Please enter unit used between 1 to 900.");
            }

            else if (rebate < 0 || rebate > 5)
            {
                cost_result.setText("Rebate must be between 0% and 5%.");
            }

            else
            {
                rebate = rebate / 100;
                float cost = 0.0F;

                if (usage >= 1 && usage <= 200)
                {
                    cost = (float) (usage * 0.218);
                }

                else if (usage >= 201 && usage <= 300)
                {
                    cost = (float) (200 * 0.218 + (usage - 200) * 0.334);
                }

                else if (usage >= 301 && usage <= 600)
                {
                    cost = (float) (200 * 0.218 + 100 * 0.334 + (usage - 300) * 0.516);
                }

                else if (usage >= 601 && usage <= 900)
                {
                    cost = (float) (200 * 0.218 + 100 * 0.334 + 300 * 0.516 + (usage - 600) * 0.546);
                }

                float finalCost = cost - (cost * rebate);

                cost_result.setText("Your estimated bill is RM" + finalCost);
            }
        }
    }

}